# Contributing to this project

Welcome are:

- ports (small demo projects) for other hardware & compilers
- benchmarks
- hints and ideas
- an e-mail about you and your project



**Working on your first Pull Request?** You can learn how from this *free* series [How to Contribute to an Open Source Project on GitHub](https://kcd.im/pull-request) 
