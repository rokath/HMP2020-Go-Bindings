# Changelog

## v0.0.0 Initial Trelease (untested)

### Added or Changed

- Setup files
<!--
- Added this changelog :)
- Fixed typos in both templates
- Back to top links
- Added more "Built With" frameworks/libraries
- Changed table of contents to start collapsed
- Added checkboxes for major features on roadmap

### Removed

- Some packages/libraries from acknowledgements I no longer use

-->
